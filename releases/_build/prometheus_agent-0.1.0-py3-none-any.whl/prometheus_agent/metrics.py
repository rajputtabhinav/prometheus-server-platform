from __future__ import annotations

import platform
import socket
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    import psutil
except ModuleNotFoundError:  # pragma: no cover
    psutil = None


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class HardwareCollectorPipeline:
    COLLECTORS = (
        "system",
        "cpu",
        "memory",
        "storage",
        "gpu",
        "network",
        "thermal_power",
        "pcie_inventory",
    )

    def __init__(self) -> None:
        self._last_network_sample = psutil.net_io_counters(pernic=True) if psutil else {}
        self._last_network_ts = time.monotonic()

    def sample(self) -> dict[str, Any]:
        if not psutil:
            return self._empty_payload()

        inventory: list[dict[str, Any]] = []
        telemetry: list[dict[str, Any]] = []
        collectors: list[dict[str, Any]] = []

        for collector_name in self.COLLECTORS:
            start = time.perf_counter()
            try:
                collector_inventory, collector_telemetry, details = getattr(self, f"_collect_{collector_name}")()
                status = "ok"
                capability_state = "available"
                message = None
            except Exception as exc:  # pragma: no cover - defensive runtime path.
                collector_inventory, collector_telemetry, details = [], [], {}
                status = "error"
                capability_state = "temporarily_failed"
                message = str(exc)

            inventory.extend(collector_inventory)
            telemetry.extend(collector_telemetry)
            collectors.append(
                {
                    "collector_name": collector_name,
                    "status": status,
                    "capability": {
                        "state": capability_state,
                        "supported": status != "unsupported",
                        "message": message,
                        "source": details.get("source"),
                    },
                    "duration_ms": round((time.perf_counter() - start) * 1000, 2),
                    "message": message,
                    "inventory": collector_inventory,
                    "telemetry": collector_telemetry,
                    "details": details,
                }
            )

        return {
            "inventory": inventory,
            "telemetry": telemetry,
            "collectors": collectors,
            "summary_metrics": self._summary_metrics(telemetry),
            "collected_at": utc_now_iso(),
        }

    def _empty_payload(self) -> dict[str, Any]:
        return {
            "inventory": [],
            "telemetry": [],
            "collectors": [
                {
                    "collector_name": collector,
                    "status": "unsupported",
                    "capability": {"state": "unsupported", "supported": False, "message": "psutil not installed", "source": None},
                    "duration_ms": 0,
                    "message": "psutil not installed",
                    "inventory": [],
                    "telemetry": [],
                    "details": {},
                }
                for collector in self.COLLECTORS
            ],
            "summary_metrics": {
                "cpu": 0,
                "memory": 0,
                "disk": 0,
                "network_mbps": 0,
                "temperature_c": None,
                "gpu_utilization": None,
            },
            "collected_at": utc_now_iso(),
        }

    def _collect_system(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        component_id = "system:host"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "system",
                "name": socket.gethostname(),
                "vendor": platform.node(),
                "model": platform.machine(),
                "status": "healthy",
                "health": "PASS",
                "capabilities": {"platform": platform.system(), "release": platform.release()},
                "metadata": {
                    "os": platform.system(),
                    "platform": platform.platform(),
                    "kernel": platform.release(),
                    "python": platform.python_version(),
                },
            }
        ]
        telemetry = []
        boot_time = getattr(psutil, "boot_time", None)
        if callable(boot_time):
            telemetry.append(
                {
                    "component_id": component_id,
                    "metric_key": "uptime_seconds",
                    "value": round(time.time() - boot_time(), 2),
                    "unit": "s",
                    "status": "ok",
                    "labels": {},
                    "recorded_at": utc_now_iso(),
                }
            )
        return inventory, telemetry, {"source": "psutil/platform"}

    def _collect_cpu(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        freq = psutil.cpu_freq()
        component_id = "cpu:package:0"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "cpu",
                "name": "CPU Package 0",
                "slot_or_path": "package:0",
                "vendor": platform.processor() or None,
                "model": platform.machine(),
                "status": "healthy",
                "health": "PASS",
                "capabilities": {"per_core_load": True, "frequency": freq is not None, "temperature": True},
                "metadata": {"logical_cores": psutil.cpu_count(), "physical_cores": psutil.cpu_count(logical=False)},
            }
        ]
        telemetry = [
            self._point(component_id, "cpu.load_percent", round(psutil.cpu_percent(interval=None), 2), "%"),
        ]
        if freq is not None:
            telemetry.extend(
                [
                    self._point(component_id, "cpu.frequency_mhz", round(freq.current, 2), "MHz"),
                    self._point(component_id, "cpu.max_frequency_mhz", round(freq.max, 2), "MHz"),
                ]
            )
        for index, value in enumerate(psutil.cpu_percent(interval=None, percpu=True)):
            telemetry.append(self._point(component_id, "cpu.core_load_percent", round(value, 2), "%", {"core": index}))
        temperature = self._read_temperature()
        if temperature is not None:
            telemetry.append(self._point(component_id, "temperature_c", temperature, "C"))
        return inventory, telemetry, {"source": "psutil"}

    def _collect_memory(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        memory = psutil.virtual_memory()
        component_id = "memory:system"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "memory",
                "name": "System Memory",
                "status": "healthy",
                "health": "PASS",
                "capabilities": {"ecc": False, "slots": False},
                "metadata": {"total_bytes": memory.total},
            }
        ]
        telemetry = [
            self._point(component_id, "memory.used_percent", round(memory.percent, 2), "%"),
            self._point(component_id, "memory.used_bytes", float(memory.used), "bytes"),
            self._point(component_id, "memory.available_bytes", float(memory.available), "bytes"),
        ]
        return inventory, telemetry, {"source": "psutil"}

    def _collect_storage(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        inventory: list[dict[str, Any]] = []
        telemetry: list[dict[str, Any]] = []
        partitions = [partition for partition in psutil.disk_partitions(all=False) if partition.mountpoint]
        io_counters = psutil.disk_io_counters(perdisk=True) or {}
        for partition in partitions:
            component_id = f"disk:{partition.device or partition.mountpoint}"
            try:
                usage = psutil.disk_usage(partition.mountpoint)
            except Exception:
                continue
            counter = next((value for key, value in io_counters.items() if partition.device and partition.device.strip("\\\\.").endswith(key)), None)
            inventory.append(
                {
                    "component_id": component_id,
                    "component_type": "storage",
                    "name": partition.device or partition.mountpoint,
                    "slot_or_path": partition.mountpoint,
                    "status": "healthy",
                    "health": "PASS",
                    "capabilities": {"smart": False, "wear": False, "filesystem_usage": True},
                    "metadata": {"fstype": partition.fstype, "opts": partition.opts},
                }
            )
            telemetry.extend(
                [
                    self._point(component_id, "disk.used_percent", round(usage.percent, 2), "%"),
                    self._point(component_id, "disk.used_bytes", float(usage.used), "bytes"),
                    self._point(component_id, "disk.free_bytes", float(usage.free), "bytes"),
                ]
            )
            if counter is not None:
                telemetry.extend(
                    [
                        self._point(component_id, "disk.read_bytes", float(counter.read_bytes), "bytes"),
                        self._point(component_id, "disk.write_bytes", float(counter.write_bytes), "bytes"),
                    ]
                )
        return inventory, telemetry, {"source": "psutil"}

    def _collect_gpu(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        component_id = "gpu:0"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "gpu",
                "name": "GPU 0",
                "status": "unknown",
                "health": "WARNING",
                "capabilities": {"utilization": False, "temperature": False, "ecc": False},
                "metadata": {"detected": False},
            }
        ]
        telemetry = [self._point(component_id, "gpu.utilization_percent", None, "%", status="unsupported")]
        return inventory, telemetry, {"source": "generic-null"}

    def _collect_network(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        inventory: list[dict[str, Any]] = []
        telemetry: list[dict[str, Any]] = []
        counters = psutil.net_io_counters(pernic=True)
        stats = psutil.net_if_stats()
        current_ts = time.monotonic()
        elapsed = max(current_ts - self._last_network_ts, 0.001)

        for name, counter in counters.items():
            component_id = f"nic:{name}"
            stat = stats.get(name)
            previous = self._last_network_sample.get(name)
            rx_mbps = tx_mbps = 0.0
            if previous is not None:
                rx_mbps = ((counter.bytes_recv - previous.bytes_recv) * 8) / elapsed / 1_000_000
                tx_mbps = ((counter.bytes_sent - previous.bytes_sent) * 8) / elapsed / 1_000_000
            inventory.append(
                {
                    "component_id": component_id,
                    "component_type": "network",
                    "name": name,
                    "slot_or_path": name,
                    "status": "healthy" if stat and stat.isup else "down",
                    "health": "PASS" if stat and stat.isup else "WARNING",
                    "capabilities": {"throughput": True, "error_counters": True, "link_speed": stat is not None},
                    "metadata": {"mtu": stat.mtu if stat else None},
                }
            )
            telemetry.extend(
                [
                    self._point(component_id, "network.rx_mbps", round(max(rx_mbps, 0), 2), "Mbps"),
                    self._point(component_id, "network.tx_mbps", round(max(tx_mbps, 0), 2), "Mbps"),
                    self._point(component_id, "network.rx_errors", float(counter.errin), "count"),
                    self._point(component_id, "network.tx_errors", float(counter.errout), "count"),
                    self._point(component_id, "network.rx_drops", float(counter.dropin), "count"),
                    self._point(component_id, "network.tx_drops", float(counter.dropout), "count"),
                ]
            )
            if stat is not None:
                telemetry.append(self._point(component_id, "network.link_speed_mbps", float(stat.speed), "Mbps"))

        self._last_network_sample = counters
        self._last_network_ts = current_ts
        return inventory, telemetry, {"source": "psutil"}

    def _collect_thermal_power(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        component_id = "thermal:board"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "thermal_power",
                "name": "Board Thermal",
                "status": "healthy",
                "health": "PASS",
                "capabilities": {"temperature": True, "fan_speed": False, "psu": False},
                "metadata": {},
            }
        ]
        temperature = self._read_temperature()
        telemetry = [self._point(component_id, "temperature_c", temperature, "C", status="ok" if temperature is not None else "unsupported")]
        return inventory, telemetry, {"source": "psutil.sensors_temperatures"}

    def _collect_pcie_inventory(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
        component_id = "pcie:inventory"
        inventory = [
            {
                "component_id": component_id,
                "component_type": "pcie_inventory",
                "name": "PCIe Inventory",
                "status": "healthy",
                "health": "PASS",
                "capabilities": {"pcie_links": False, "firmware_inventory": True},
                "metadata": {"platform": platform.platform()},
            }
        ]
        return inventory, [], {"source": "platform"}

    def _summary_metrics(self, telemetry: list[dict[str, Any]]) -> dict[str, Any]:
        value_map = {entry["metric_key"]: entry.get("value") for entry in telemetry}
        disk_percent = next((entry.get("value") for entry in telemetry if entry["metric_key"] == "disk.used_percent"), 0)
        network_mbps = sum(
            float(entry.get("value") or 0)
            for entry in telemetry
            if entry["metric_key"] in {"network.rx_mbps", "network.tx_mbps"}
        )
        return {
            "cpu": float(value_map.get("cpu.load_percent") or 0),
            "memory": float(value_map.get("memory.used_percent") or 0),
            "disk": float(disk_percent or 0),
            "network_mbps": round(network_mbps, 2),
            "temperature_c": value_map.get("temperature_c"),
            "gpu_utilization": value_map.get("gpu.utilization_percent"),
        }

    @staticmethod
    def _read_temperature() -> float | None:
        if not hasattr(psutil, "sensors_temperatures"):
            return None
        try:
            readings = psutil.sensors_temperatures()
        except Exception:
            return None
        for entries in readings.values():
            if entries:
                return round(entries[0].current, 2)
        return None

    @staticmethod
    def _point(component_id: str, metric_key: str, value: float | None, unit: str | None, labels: dict[str, Any] | None = None, status: str = "ok") -> dict[str, Any]:
        return {
            "component_id": component_id,
            "metric_key": metric_key,
            "value": value,
            "unit": unit,
            "status": status if value is not None else status,
            "labels": labels or {},
            "recorded_at": utc_now_iso(),
        }


class MetricsSampler:
    def __init__(self) -> None:
        self.pipeline = HardwareCollectorPipeline()

    def sample(self) -> dict[str, Any]:
        return self.pipeline.sample()["summary_metrics"]

    def sample_hardware(self) -> dict[str, Any]:
        return self.pipeline.sample()
