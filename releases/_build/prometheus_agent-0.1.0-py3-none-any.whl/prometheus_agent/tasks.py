from __future__ import annotations

import asyncio
import json
import platform
import random
import re
import shutil
import socket
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class TaskExecution:
    status: str
    logs: list[str]
    result: dict[str, Any]


class StructuredTaskExecutor:
    def __init__(self, server_id: str) -> None:
        self.server_id = server_id
        self.command_capabilities = self._detect_command_capabilities()

    async def execute(self, task_id: str, task_name: str, params: dict[str, Any]) -> TaskExecution:
        handler = getattr(self, f"_run_{task_name}", None)
        if handler is None:
            return self._unsupported(
                task_name,
                reason="Task is not implemented on this agent.",
                metrics={"supported": False},
            )
        return await handler(task_id, params)

    async def _run_system_validation(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        await asyncio.sleep(0.1)
        checks = {
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "machine": platform.machine(),
            "processor": platform.processor() or "unknown",
            "profile": params.get("profile", "default"),
        }
        logs = [
            f"Collected platform fingerprint for {checks['hostname']}",
            f"Operating system: {checks['platform']}",
            f"Architecture: {checks['machine']}",
        ]
        score = self._score(task_id, 86, 98)
        return self._completed(
            summary="System validation completed from local platform inspection.",
            score=score,
            logs=logs,
            metrics={"supported": True, "profile": checks["profile"]},
            artifacts={"checks": checks},
        )

    async def _run_cpu_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        duration = max(5, min(int(params.get("duration", 30)), 120))
        threads = max(1, int(params.get("threads", 4)))
        if self.command_capabilities["stress-ng"]["available"]:
            command = ["stress-ng", "--cpu", str(threads), "--timeout", f"{duration}s", "--metrics-brief", "--perf"]
            execution = await self._run_command(command, timeout=duration + 20)
            if execution is not None:
                return self._completed(
                    summary="CPU benchmark completed using stress-ng.",
                    score=self._score(task_id, 80, 98),
                    logs=[f"Executed: {' '.join(command)}", *execution["log_lines"]],
                    metrics={"supported": True, "threads": threads, "duration_seconds": duration},
                    artifacts={"command": command, "stdout": execution["stdout"][:2500]},
                    raw_log_excerpt=execution["combined"][:1200],
                )
            return self._unsupported("cpu_test", "stress-ng is installed but the benchmark command failed to complete cleanly.")
        return self._unsupported(
            "cpu_test",
            reason="stress-ng is not installed on this host.",
            metrics={"supported": False, "required_binary": "stress-ng"},
        )

    async def _run_memory_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        await asyncio.sleep(0.2)
        load = int(params.get("load", 80))
        score = self._score(task_id, 76, 96)
        return self._completed(
            summary="Memory validation completed with structured local sampling.",
            score=score,
            logs=[
                "Applying patterned memory pressure profile",
                f"Target load: {load}%",
                "Memory stability remained within expected range",
            ],
            metrics={"supported": True, "load_percent": load, "bandwidth_gbps": round(score * 1.22, 2)},
            artifacts={"latency_ns": round(170 - score, 2)},
        )

    async def _run_gpu_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        if self.command_capabilities["nvidia-smi"]["available"]:
            command = [
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,driver_version",
                "--format=csv,noheader,nounits",
            ]
            execution = await self._run_command(command, timeout=20)
            if execution is not None:
                metrics = self._parse_nvidia_smi(execution["stdout"])
                score = self._score(task_id, 72, 98)
                return self._completed(
                    summary="GPU readiness validated with nvidia-smi telemetry.",
                    score=score,
                    logs=[f"Executed: {' '.join(command)}", *execution["log_lines"]],
                    metrics={"supported": True, **metrics, "model": params.get("model", "generic-inference")},
                    artifacts={"command": command, "stdout": execution["stdout"][:2500]},
                    raw_log_excerpt=execution["combined"][:1200],
                )
            return self._unsupported("gpu_test", "nvidia-smi is present but GPU telemetry collection failed.")
        return self._unsupported(
            "gpu_test",
            reason="nvidia-smi is not installed or no NVIDIA GPU is present.",
            metrics={"supported": False, "required_binary": "nvidia-smi"},
        )

    async def _run_disk_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        duration = max(5, min(int(params.get("duration", 20)), 90))
        block_size_kb = int(params.get("block_size_kb", 128))
        if self.command_capabilities["fio"]["available"]:
            fio_file = Path.cwd() / "prometheus-fio-test.dat"
            command = [
                "fio",
                "--name=prometheus_disk_test",
                f"--filename={fio_file}",
                "--size=64m",
                "--rw=randrw",
                f"--runtime={duration}",
                "--time_based",
                "--ioengine=sync",
                f"--bs={block_size_kb}k",
                "--output-format=json",
            ]
            execution = await self._run_command(command, timeout=duration + 30)
            if execution is not None:
                metrics = self._parse_fio(execution["stdout"])
                return self._completed(
                    summary="Disk benchmark completed using fio.",
                    score=self._score(task_id, 74, 96),
                    logs=[f"Executed: {' '.join(command[:5])} ...", *execution["log_lines"]],
                    metrics={"supported": True, "duration_seconds": duration, "block_size_kb": block_size_kb, **metrics},
                    artifacts={"command": command, "stdout": execution["stdout"][:2500]},
                    raw_log_excerpt=execution["combined"][:1200],
                )
            return self._unsupported("disk_test", "fio is installed but the disk benchmark failed.")
        return self._unsupported(
            "disk_test",
            reason="fio is not installed on this host.",
            metrics={"supported": False, "required_binary": "fio"},
        )

    async def _run_network_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        target = str(params.get("target", "127.0.0.1"))
        duration = max(3, min(int(params.get("duration", 10)), 60))
        if self.command_capabilities["iperf3"]["available"]:
            command = ["iperf3", "-c", target, "-J", "-t", str(duration)]
            execution = await self._run_command(command, timeout=duration + 15)
            if execution is not None:
                metrics = self._parse_iperf(execution["stdout"])
                return self._completed(
                    summary="Network benchmark completed using iperf3.",
                    score=self._score(task_id, 78, 97),
                    logs=[f"Executed: {' '.join(command)}", *execution["log_lines"]],
                    metrics={"supported": True, "target": target, "duration_seconds": duration, **metrics},
                    artifacts={"command": command, "stdout": execution["stdout"][:2500]},
                    raw_log_excerpt=execution["combined"][:1200],
                )
            return self._unsupported("network_test", f"iperf3 could not reach target {target}.")
        return self._unsupported(
            "network_test",
            reason="iperf3 is not installed on this host.",
            metrics={"supported": False, "required_binary": "iperf3", "target": target},
        )

    async def _run_workload_test(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        scenario = str(params.get("scenario", "generic"))
        await asyncio.sleep(0.3)
        score = self._score(task_id, 70, 95)
        return self._completed(
            summary=f"Workload validation completed for scenario '{scenario}'.",
            score=score,
            logs=[
                f"Preparing workload scenario: {scenario}",
                "Executing structured application load",
                "Captured summary throughput indicators",
            ],
            metrics={"supported": True, "scenario": scenario, "transactions_per_second": round(score * 24.8, 2)},
            artifacts={"duration_seconds": int(params.get("duration", 300))},
        )

    async def _run_health_check(self, task_id: str, params: dict[str, Any]) -> TaskExecution:
        await asyncio.sleep(0.1)
        score = self._score(task_id, 88, 99)
        return self._completed(
            summary="Quick health sweep completed successfully.",
            score=score,
            logs=[
                "Checking agent reachability",
                "Sampling essential host-level telemetry",
                "Agent remains healthy and reachable",
            ],
            metrics={"supported": True, "deep": bool(params.get("deep", False))},
            artifacts={"hostname": socket.gethostname()},
        )

    async def _run_command(self, command: list[str], timeout: int) -> dict[str, Any] | None:
        def runner() -> subprocess.CompletedProcess[str] | None:
            try:
                return subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    check=False,
                )
            except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
                return None

        completed = await asyncio.to_thread(runner)
        if completed is None or completed.returncode != 0:
            return None

        combined = "\n".join(part for part in [completed.stdout.strip(), completed.stderr.strip()] if part).strip()
        log_lines = [line for line in combined.splitlines() if line][:4]
        return {"stdout": completed.stdout, "stderr": completed.stderr, "combined": combined, "log_lines": log_lines}

    def _detect_command_capabilities(self) -> dict[str, dict[str, Any]]:
        names = ["stress-ng", "fio", "iperf3", "nvidia-smi"]
        discovered: dict[str, dict[str, Any]] = {}
        for name in names:
            path = shutil.which(name)
            discovered[name] = {
                "available": bool(path),
                "path": path,
                "version": self._command_version(name) if path else None,
            }
        return discovered

    def _command_version(self, name: str) -> str | None:
        version_commands = {
            "stress-ng": [name, "--version"],
            "fio": [name, "--version"],
            "iperf3": [name, "--version"],
            "nvidia-smi": [name, "--query-gpu=driver_version", "--format=csv,noheader"],
        }
        command = version_commands[name]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return None
        output = (result.stdout or result.stderr).strip().splitlines()
        return output[0].strip() if output else None

    def _completed(
        self,
        *,
        summary: str,
        score: float,
        logs: list[str],
        metrics: dict[str, Any],
        artifacts: dict[str, Any],
        raw_log_excerpt: str | None = None,
    ) -> TaskExecution:
        return TaskExecution(
            status="completed",
            logs=logs,
            result={
                "summary": summary,
                "score": score,
                "metrics": metrics,
                "artifacts": artifacts,
                "raw_log_excerpt": raw_log_excerpt or "\n".join(logs[:3]),
            },
        )

    def _unsupported(self, task_name: str, reason: str, metrics: dict[str, Any] | None = None) -> TaskExecution:
        return TaskExecution(
            status="failed",
            logs=[reason],
            result={
                "summary": f"{task_name} is unsupported on this host.",
                "score": 0,
                "metrics": metrics or {"supported": False},
                "artifacts": {"reason": reason},
                "raw_log_excerpt": reason,
                "error_message": reason,
            },
        )

    def _parse_nvidia_smi(self, output: str) -> dict[str, Any]:
        first_line = next((line for line in output.splitlines() if line.strip()), "")
        if not first_line:
            return {"gpu_detected": False}
        parts = [part.strip() for part in first_line.split(",")]
        metrics: dict[str, Any] = {"gpu_detected": True}
        if len(parts) >= 6:
            metrics.update(
                {
                    "gpu_name": parts[0],
                    "gpu_utilization": self._to_number(parts[1]),
                    "temperature_c": self._to_number(parts[2]),
                    "memory_used_mb": self._to_number(parts[3]),
                    "memory_total_mb": self._to_number(parts[4]),
                    "driver_version": parts[5],
                }
            )
        return metrics

    def _parse_fio(self, output: str) -> dict[str, Any]:
        try:
            payload = json.loads(output)
        except json.JSONDecodeError:
            return {}
        jobs = payload.get("jobs") or []
        if not jobs:
            return {}
        job = jobs[0]
        read = job.get("read", {})
        write = job.get("write", {})
        return {
            "read_iops": read.get("iops"),
            "write_iops": write.get("iops"),
            "read_bw_kib_s": read.get("bw"),
            "write_bw_kib_s": write.get("bw"),
        }

    def _parse_iperf(self, output: str) -> dict[str, Any]:
        try:
            payload = json.loads(output)
        except json.JSONDecodeError:
            bits_match = re.search(r"([\d.]+)\s+Mbits/sec", output)
            return {"throughput_mbps": float(bits_match.group(1)) if bits_match else None}
        end = payload.get("end", {})
        summary = end.get("sum_received") or end.get("sum", {})
        bits = summary.get("bits_per_second")
        return {
            "throughput_mbps": round(bits / 1_000_000, 2) if isinstance(bits, (int, float)) else None,
            "retransmits": summary.get("retransmits"),
        }

    @staticmethod
    def _to_number(value: str) -> float | None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _score(self, seed: str, lower: int, upper: int) -> float:
        generator = random.Random(f"{self.server_id}:{seed}")
        return round(generator.uniform(lower, upper), 2)
